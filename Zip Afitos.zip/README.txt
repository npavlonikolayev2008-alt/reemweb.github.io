Restaurant Afitos Website

How to use:
1. Open index.html in any browser.
2. To publish it online, upload index.html to a hosting service such as Netlify, Vercel, GitHub Pages, or your web hosting provider.
3. Replace text, opening hours, prices, or photos whenever the restaurant provides official details.

Files:
- index.html: full one-page responsive website with all styling included.
